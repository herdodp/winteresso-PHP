<?php 

require_once "../winteresso/winteresso.php";

// WIN_CONNECT_DB("servername", "username", "password", "database");


 ?>