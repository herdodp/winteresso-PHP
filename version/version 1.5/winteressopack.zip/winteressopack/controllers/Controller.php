<?php 

class Controller {
	public function meta() {
		require "core/meta.php";
	}

	public function header() {
		require "core/header.php";
	}

	public function content() {
		require "core/content.php";
	}

	public function footer() {
		require "core/footer.php";
	}
}


 ?>