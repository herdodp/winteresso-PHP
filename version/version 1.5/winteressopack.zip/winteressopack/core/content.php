<?php 
include_once "winteresso/winteresso.php";
 ?>
<div>
	<h1 class="test"><?php WINPRINT("WELCOME TO WINTERESSO"); ?></h1>
</div>