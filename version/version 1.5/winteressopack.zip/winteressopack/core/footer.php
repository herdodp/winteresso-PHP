<?php 
include_once "winteresso/winteresso.php";
 ?>


<!-- place footer here -->
<div style="margin-top: 50px; bottom: 0;left: 0;right: 0;background-color: #000000;padding: 10px;position: absolute;text-align: center;">
	<span style="color: #ffffff; font-weight: bolder;">© 2022 Winteresso</span>
</div>



</body>
</html>