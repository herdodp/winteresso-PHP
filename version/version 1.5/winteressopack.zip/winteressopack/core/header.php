<nav style="display: flex;justify-content: space-between; background-color: #000000;top: 0; left: 0;right: 0;">
	<div style="display: flex;flex-direction: row;margin: 10px;">
		<a href="" style="text-decoration: none;margin: 10px;color: #ffffff;">Home</a>
		<a href="" style="text-decoration: none;margin: 10px;color: #ffffff;">Profil</a>
		<a href="" style="text-decoration: none;margin: 10px;color: #ffffff;">About</a>
	</div>

	<div style="display: flex;flex-direction: row;margin: 10px;">
		<a href="features/login.php" style="text-decoration: none;margin: 10px;color: #ffffff;">Login</a>
		<a href="features/register.php" style="text-decoration: none;margin: 10px;color: #ffffff;">Register</a>
	</div>
</nav>