<!DOCTYPE html>
<html lang="en">
<head>
    <!-- meta tag -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="">
    <meta name="description" content="">
    <meta name="keywords" content="">

    <!-- title -->
    <title>Index</title>

    <!-- icon tag -->
    <link rel="icon" type="image/x-icon" href="/img/your_icon.ico">

    <!-- style CSS -->
    <link rel="stylesheet" type="text/css" href="css/style.css">

    <!-- javascript -->
    <script type="text/javascript" src="js/src.js"></script>
</head>


<body>