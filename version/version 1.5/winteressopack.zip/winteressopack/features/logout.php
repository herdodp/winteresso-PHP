<?php 
	require_once '../winteresso/winteresso.php';
	WIN_LOGOUT("../index.php");
 ?>