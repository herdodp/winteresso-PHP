(indonesian language)
* semua komponen navbar di header.php, isi web di content.php, komponen footer di footer.php. semua berada dalam
folder core

* pada folder css terdapat style.css untuk styling
* pada folder enginee terdapat file algoritma terpisah. Default : login_enginee.php & register_enginee.php
* pada folder features berisi file fitur - fitur dalam web. Default : login.php, register.php, logout.php
* pada folder js terdapat file src.js untuk tempat code - code javascript
* pada folder views berisi file views.php untuk menampilkan view website
* pada folder config terdapat file config.php untuk konfigurasi database,dll.
* pada folder controllers berisi file route.php sebagai routing url

file database ada di folder config

jika ada permasalahan, silahkan hubungi :
Email : herdodimas46@gmail.com
Instagram : herdodp
Github : github.com/herdodp22
Linkedin : linkedin.com/in/herdodimasp