<?php 

require_once "winteresso/winteresso.php";

WIN_CONNECT_DB("localhost", "root", "", "winteresso_db");


 ?>